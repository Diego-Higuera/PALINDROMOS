/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindromos;

import javax.swing.JOptionPane;
import static palindromos.Palindromo.validPalindrome;

/**
 *
 * @author Lenovo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String s = (JOptionPane.showInputDialog(
                null,
                "Escribe tu palindromo",
                "palindromo",
                JOptionPane.QUESTION_MESSAGE));
        s = s.toLowerCase();
        s = s.replace(" ", "");
        s = s.replace("á", "a");
        s = s.replace("é", "e");
        s = s.replace("í", "i");
        s = s.replace("ó", "o");
        s = s.replace("ú", "u");
        s = s.replace("ü", "u");
        s = s.replaceAll("[^\\da-z]", "");

        boolean b1 = validPalindrome(s);

        //System.out.println(b1);
        JOptionPane.showMessageDialog(
                null,
                "palindromo: " + b1,
                "Palindromo",
                JOptionPane.INFORMATION_MESSAGE);

    }
}
